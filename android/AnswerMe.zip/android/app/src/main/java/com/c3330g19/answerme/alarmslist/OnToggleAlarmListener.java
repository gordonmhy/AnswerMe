package com.c3330g19.answerme.alarmslist;

import com.c3330g19.answerme.data.Alarm;

public interface OnToggleAlarmListener {
    void onToggle(Alarm alarm);
}
